# FPS Optimizer — Shizuku, No Root

Boosts FPS for MCPE, MLBB, CODM, Car Parking Multiplayer 2, Roblox.
Tested target device: Infinix X6881 (Helio G99, Android 13).

## How to build the APK (GitHub Actions — no PC needed)

1. Go to github.com → create free account
2. New repository → upload all these files (maintain folder structure)
3. Go to Actions tab → "Build FPS Optimizer APK" → Run workflow
4. Wait ~4 minutes → download `fps-optimizer-debug` artifact → unzip → install APK

## How to use the APK

1. Install Shizuku from Play Store
2. Open Shizuku → start via Wireless ADB (no root, Android 11+):
   - Enable Developer Options → Wireless debugging
   - In Shizuku: "Start via Wireless ADB" → pair
3. Open FPS Optimizer
4. Select your game profile
5. Tap BOOST — grants Shizuku permission on first run, applies all optimizations, launches game
6. Tap RESET when done gaming (restores display density + animations)

## Profiles

| Profile | FPS Target | Density |
|---|---|---|
| MCPE — Vibrant Visuals | 60–80 | 280dpi |
| MCPE — Standard | 90–120 | 320dpi |
| MLBB | 90–120 | native |
| CODM | 90–120 | native |
| Car Parking Multiplayer 2 | 90–120 | 320dpi |
| Roblox | 90–120 | 320dpi |

## What it does (Shizuku shell uid levers)

- Kills background processes + GMS sync
- Zeros animation scales (window, transition, animator)
- Disables battery saver + adaptive battery + app standby
- Fires MediaTek PerfBoost broadcast
- Locks refresh rate (peak + min) to target FPS via settings provider
- Drops display density to reduce GPU load (MCPE profiles)
- Enables WiFi high-performance + low-latency mode
- Reapplies every 60s via foreground service (fights thermal governor resets)

## Note on overclocking

True CPU frequency overclocking above stock max requires root + kernel write access.
Shell uid (Shizuku) cannot write /sys/devices/system/cpu/*/cpufreq/scaling_max_freq.
Everything above is the complete non-root optimization surface — no stub, no fake.
