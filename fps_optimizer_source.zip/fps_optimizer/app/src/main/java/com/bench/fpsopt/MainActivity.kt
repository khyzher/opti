package com.bench.fpsopt

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bench.fpsopt.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

private const val PERM_CODE = 42

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var selectedProfile = 0

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) onPermissionGranted()
        else toast("Shizuku permission denied — open Shizuku and grant access to this app")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        Shizuku.addRequestPermissionResultListener(permListener)

        b.profileSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            Profiles.ALL.map { it.displayName }
        )
        b.profileSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                selectedProfile = pos
                updateProfileInfo(Profiles.ALL[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        b.btnBoost.setOnClickListener  { checkAndBoost() }
        b.btnStop.setOnClickListener   { stopOptimizer() }
        b.btnReset.setOnClickListener  {
            lifecycleScope.launch {
                if (!ShizukuManager.isAvailable || !ShizukuManager.hasPermission) {
                    toast("Shizuku not ready"); return@launch
                }
                ShizukuManager.bindService()
                b.logView.text = ProfileEngine.reset().joinToString("\n")
                toast("Settings reset to default")
            }
        }

        updateShizukuStatus()
    }

    private fun updateShizukuStatus() {
        b.statusText.text = when {
            !ShizukuManager.isAvailable  -> "⚠ Shizuku not running — start it in the Shizuku app"
            !ShizukuManager.hasPermission -> "⚠ Shizuku running — tap BOOST to grant permission"
            else                          -> "✓ Shizuku ready"
        }
    }

    private fun updateProfileInfo(p: GameProfile) {
        b.profileInfo.text =
            "Target: ${p.targetFpsLow}–${p.targetFpsHigh} FPS  |  " +
            "Density: ${if (p.densityScale > 0) "${p.densityScale}dpi" else "default"}  |  " +
            "Package: ${p.packageName}"
    }

    private fun checkAndBoost() {
        if (!ShizukuManager.isAvailable)  { toast("Start Shizuku first"); return }
        if (!ShizukuManager.hasPermission) { ShizukuManager.requestPermission(PERM_CODE); return }
        onPermissionGranted()
    }

    private fun onPermissionGranted() {
        lifecycleScope.launch {
            b.logView.text = "Binding Shizuku service…"
            val bound = ShizukuManager.bindService()
            if (!bound) { toast("Failed to bind Shizuku user service"); return@launch }

            val profile = Profiles.ALL[selectedProfile]
            b.logView.text = "Applying: ${profile.displayName}…"

            val log = ProfileEngine.apply(profile)
            b.logView.text = log.joinToString("\n")

            startForegroundService(
                Intent(this@MainActivity, OptimizerService::class.java).apply {
                    action = OptimizerService.ACTION_START
                    putExtra(OptimizerService.EXTRA_PROFILE, selectedProfile)
                }
            )
            toast("✓ ${profile.displayName} active")
        }
    }

    private fun stopOptimizer() {
        startService(Intent(this, OptimizerService::class.java).apply {
            action = OptimizerService.ACTION_STOP
        })
        toast("Optimizer stopped")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }
}
