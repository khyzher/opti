package com.bench.fpsopt

import android.os.IBinder

class UserService : IUserService.Stub() {

    override fun runCommand(cmd: String): String {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val out  = proc.inputStream.bufferedReader().readText()
            val err  = proc.errorStream.bufferedReader().readText()
            proc.waitFor()
            (out + err).trim().ifEmpty { "ok" }
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    override fun destroy() {}

    override fun asBinder(): IBinder = this
}
